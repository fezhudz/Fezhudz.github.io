# FEZ_HUDZ Security website

A static website for GitHub Pages.

## Publish
1. Sign in to GitHub as `Fezhudz`.
2. Create a **public** repository named exactly `Fezhudz.github.io` (GitHub usernames are case-insensitive).
3. Upload `index.html` to the repository root and commit it to the `main` branch.
4. Open repository **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**, `main`, `/ (root)`, then Save.
5. Wait for GitHub Pages deployment and visit https://fezhudz.github.io.

Review all site text and ensure it accurately represents your work before publishing. A GitHub Pages site does not guarantee acceptance of a third-party verification application.
